@extends('template')
@section('content')
<section class="main-section">
        <div class="content">
            <h1>Ubah Penjualan</h1>
            <hr>
            @if($errors->any())
                <div class="alert alert-danger">
                    @foreach($errors->all() as $error)
                        <li><strong>{{ $error }}</strong>
                    @endforeach
            </div>
        @endif

        @foreach($data as $datas)
        <form action="{{ route('penjualan.update', $datas->id) }}" method="post">
            {{ csrf_field() }}
            {{ method_field('PUT') }}
            <div class="form-group">
                <label for="kd_barang">kd_barang:</label>
                <input type="text" class="form-control" id="brng" name="kd_barang" value="{{ $datas->kd_barang }}">
            </div>
            <div class="form-group">
                <label for="jual">jual:</label>
                <input type="text" class="form-control" id="jual" name="jual" value="{{ $datas->jual }}">
            </div>
            <div class="form-group">
                <label for="total_harga">total_harga:</label>
                <input type="text" class="form-control" id="ttl" name="total_harga" value="{{ $datas->total_harga }}">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Submit</button>
                <button type="reset" class="btn btn-md btn-danger">Cancel</button>
            </div>
        </form>
        @endforeach
    </div>
</section>
@endsection