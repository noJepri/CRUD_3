<?php $__env->startSection('content'); ?>
    <section class="main-section">
        <div class="content">
            <h1>Penjualan</h1>
            <hr>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong><?php echo e($error); ?></strong>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('penjualan.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="kd_barang">kd_barang:</label>
                <input type="text" class="form-control" id="brng" name="kd_barang">
            </div>
            <div class="form-group">
                <label for="jual">jual:</label>
                <input type="text" class="form-control" id="jual" name="jual">
            </div>
            <div class="form-group">
                <label for="total_harga">total_harga:</label>
                <input type="text" class="form-control" id="ttl" name="total_harga">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Submit</button>
                <button type="reset" class="btn btn-md btn-danger">Cancel</button>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\uwu\resources\views/penjualan_create.blade.php ENDPATH**/ ?>