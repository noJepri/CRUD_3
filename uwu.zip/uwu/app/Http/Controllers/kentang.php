<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class kentang extends Controller
{
    //
    public function sandal(){
        echo ' sandal swallow';
    }
}
